const {
    getProjects,
    createProject
} = require("../models/projectModel");

exports.getProjects = async (req, res) => {
    try {
        const projects = await getProjects(req.user.id);
        res.json(projects);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server Error" });
    }
};

exports.addProject = async (req, res) => {
    console.log("HEADERS:", req.headers);
    console.log("BODY:", req.body);
    console.log("USER:", req.user);

    res.json({
        body: req.body,
        user: req.user
    });
};

exports.updateProject = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description, status } = req.body;

        const project = await updateProject(id, title, description, status);
        res.json(project);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server Error" });
    }
};

exports.deleteProject = async (req, res) => {
    try {
        const { id } = req.params;
        await deleteProject(id);
        res.json({ message: "Project deleted successfully" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server Error" });
    }
};