const express = require("express");
const router = express.Router();

router.post("/", (req, res) => {
    console.log("✅ PROJECT ROUTE HIT");
    console.log(req.body);

    res.json({
        success: true,
        body: req.body
    });
});

module.exports = router;