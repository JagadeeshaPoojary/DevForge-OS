const express = require("express");
const cors = require("cors");
require("dotenv").config();

const db = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const authMiddleware = require("./middleware/authMiddleware");
const plannerRoutes = require("./routes/plannerRoutes");
const app = express();
const projectRoutes = require("./routes/projectRoutes");

app.use("/api/projects", projectRoutes);
app.use(cors());
app.use(express.json());
app.use("/api/planner", plannerRoutes);
app.use("/api/auth", authRoutes);

app.get("/", (req, res) => {
    res.send("🚀 DevForge OS Backend Running");
});

app.get("/api/profile", authMiddleware, (req, res) => {
    res.json({
        success: true,
        message: "Protected Route Accessed Successfully",
        user: req.user
    });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});